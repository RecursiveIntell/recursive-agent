//! recursive-agent daemon — Unix-socket listener that accepts run specs
//! and executes them through the receipt-bearing runner.
//!
//! No unsafe, no panic. Every accepted run is a new receipt chain.

use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::path::{Path, PathBuf};

use recursive_agent_contracts::RunSpecV1;
use recursive_agent_runner::run_spec;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum DaemonError {
    #[error("io: {0}")]
    Io(#[from] std::io::Error),
    #[error("socket already exists: {0}")]
    SocketExists(PathBuf),
    #[error("json: {0}")]
    Json(#[from] serde_json::Error),
    #[error("runner: {0}")]
    Runner(#[from] recursive_agent_runner::RunError),
}

pub struct DaemonConfig {
    pub socket_path: PathBuf,
    pub runs_root: PathBuf,
    pub max_concurrent_runs: usize,
}

impl DaemonConfig {
    pub fn new(socket_path: PathBuf, runs_root: PathBuf) -> Self {
        Self {
            socket_path,
            runs_root,
            max_concurrent_runs: 4,
        }
    }
}

/// Start the daemon, blocking forever on `accept()`.
pub fn start(config: &DaemonConfig) -> Result<(), DaemonError> {
    if config.socket_path.exists() {
        std::fs::remove_file(&config.socket_path)?;
    }
    if let Some(parent) = config.socket_path.parent() {
        std::fs::create_dir_all(parent)?;
    }

    let listener = UnixListener::bind(&config.socket_path)?;
    eprintln!("daemon listening on {}", config.socket_path.display());

    for stream in listener.incoming() {
        let stream = stream?;
        let runs_root = config.runs_root.clone();
        std::thread::spawn(move || {
            if let Err(e) = handle_connection(stream, &runs_root) {
                eprintln!("connection error: {e}");
            }
        });
    }
    Ok(())
}

fn handle_connection(mut stream: UnixStream, runs_root: &Path) -> Result<(), DaemonError> {
    let reader = BufReader::new(stream.try_clone()?);
    let mut spec_json = String::new();
    for line in reader.lines() {
        spec_json.push_str(&line?);
        spec_json.push('\n');
    }

    if spec_json.trim().is_empty() {
        let _ = writeln!(stream, r#"{{"error":"empty run spec"}}"#);
        return Ok(());
    }

    let spec: RunSpecV1 = serde_json::from_str(&spec_json)?;
    let summary = run_spec(&spec, runs_root)?;

    let response = serde_json::json!({
        "run_id": summary.run_id,
        "run_dir": summary.run_dir.to_string_lossy(),
        "chain_length": summary.chain_length,
        "chain_head": summary.chain_head,
    });
    let _ = writeln!(stream, "{}", serde_json::to_string(&response)?);
    Ok(())
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::os::unix::net::UnixStream;
    use std::time::Duration;

    #[test]
    fn daemon_accepts_and_runs_echo_spec() {
        let tmp = tempfile::tempdir().unwrap();
        let socket = tmp.path().join("ra.sock");
        let runs = tmp.path().join("runs");
        let runs_clone = runs.clone();

        let config = DaemonConfig::new(socket.clone(), runs_clone);
        let socket_clone = socket.clone();

        // Start daemon in background thread.
        let _handle = std::thread::spawn(move || {
            let _ = start(&config);
        });

        // Give daemon time to bind.
        std::thread::sleep(Duration::from_millis(100));

        // Connect and send a run spec.
        let mut stream = UnixStream::connect(&socket_clone).expect("connect");
        let spec = serde_json::json!({
            "name": "daemon-test",
            "policy_version": "m0-2",
            "steps": [
                {"name": "s1", "call": {"tool": "echo", "args": {"text": "daemon-hi"}}}
            ]
        });
        writeln!(stream, "{}", serde_json::to_string(&spec).unwrap()).unwrap();
        drop(stream);

        // Wait a bit for handler to finish.
        std::thread::sleep(Duration::from_millis(200));

        // Don't try to join — daemon blocks on accept().
        // Just verify the run directory was created.
        let run_dirs: Vec<_> = std::fs::read_dir(&runs)
            .unwrap()
            .filter_map(|e| e.ok())
            .collect();
        assert!(!run_dirs.is_empty(), "run directory should exist");
    }

    #[test]
    fn empty_connection_is_rejected() {
        let tmp = tempfile::tempdir().unwrap();
        let socket = tmp.path().join("ra2.sock");
        let runs = tmp.path().join("runs2");

        let config = DaemonConfig::new(socket.clone(), runs);
        let socket_clone = socket.clone();

        let _handle = std::thread::spawn(move || {
            let _ = start(&config);
        });
        std::thread::sleep(Duration::from_millis(100));

        let stream = UnixStream::connect(&socket_clone).unwrap();
        // Send nothing — just close.
        drop(stream);
        std::thread::sleep(Duration::from_millis(100));
        // Should not crash.
    }
}
