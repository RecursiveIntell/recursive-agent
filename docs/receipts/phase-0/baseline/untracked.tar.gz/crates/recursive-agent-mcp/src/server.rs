//! MCP server — exposes recursive-agent tools over the MCP stdio protocol.
//!
//! Reads JSON-RPC from stdin, dispatches to local tool execution,
//! writes JSON-RPC responses to stdout.

use crate::protocol::{JsonRpcError, JsonRpcRequest, JsonRpcResponse, McpError, ToolManifest};
use std::io::BufRead;

/// Run the MCP server on stdio. Blocks until stdin is closed.
pub fn serve_stdio() -> Result<(), McpError> {
    let stdin = std::io::stdin();
    let reader = std::io::BufReader::new(stdin.lock());

    for line in reader.lines() {
        let line = line.map_err(|e| McpError::Io(e.to_string()))?;
        if line.trim().is_empty() {
            continue;
        }
        let request: JsonRpcRequest = match serde_json::from_str(line.trim()) {
            Ok(r) => r,
            Err(e) => {
                let err = JsonRpcResponse {
                    jsonrpc: "2.0".into(),
                    id: 0,
                    result: None,
                    error: Some(JsonRpcError {
                        code: -32700,
                        message: format!("Parse error: {e}"),
                    }),
                };
                eprintln!("{}", serde_json::to_string(&err).unwrap_or_default());
                continue;
            }
        };

        let response = handle_request(&request);
        let out = serde_json::to_string(&response).map_err(McpError::Json)?;
        println!("{out}");
    }
    Ok(())
}

fn handle_request(req: &JsonRpcRequest) -> JsonRpcResponse {
    match req.method.as_str() {
        "initialize" => {
            let result = serde_json::json!({
                "protocol_version": "2024-11-05",
                "server_info": {"name": "recursive-agent", "version": "0.1.0"},
                "capabilities": {"tools": {}}
            });
            JsonRpcResponse {
                jsonrpc: "2.0".into(),
                id: req.id,
                result: Some(result),
                error: None,
            }
        }
        "tools/list" => {
            let tools = available_tools();
            let result = serde_json::json!({"tools": tools});
            JsonRpcResponse {
                jsonrpc: "2.0".into(),
                id: req.id,
                result: Some(result),
                error: None,
            }
        }
        "tools/call" => match handle_tool_call(req) {
            Ok(value) => JsonRpcResponse {
                jsonrpc: "2.0".into(),
                id: req.id,
                result: Some(
                    serde_json::json!({"content": [{"type": "text", "text": value.to_string()}]}),
                ),
                error: None,
            },
            Err(msg) => JsonRpcResponse {
                jsonrpc: "2.0".into(),
                id: req.id,
                result: None,
                error: Some(JsonRpcError {
                    code: -32000,
                    message: msg,
                }),
            },
        },
        _ => JsonRpcResponse {
            jsonrpc: "2.0".into(),
            id: req.id,
            result: None,
            error: Some(JsonRpcError {
                code: -32601,
                message: format!("Method not found: {}", req.method),
            }),
        },
    }
}

fn handle_tool_call(req: &JsonRpcRequest) -> Result<serde_json::Value, String> {
    let params = req.params.as_ref().ok_or("missing params")?;
    let name = params["name"].as_str().ok_or("missing tool name")?;
    let args = params
        .get("arguments")
        .cloned()
        .unwrap_or(serde_json::Value::Null);

    match name {
        "echo" => {
            let text = args["text"].as_str().unwrap_or("");
            Ok(serde_json::json!({"text": text}))
        }
        "time_now" => Ok(serde_json::json!({"timestamp": chrono::Utc::now().to_rfc3339()})),
        other => Err(format!("unknown tool: {other}")),
    }
}

fn available_tools() -> Vec<ToolManifest> {
    vec![
        ToolManifest {
            name: "echo".into(),
            description: Some("Returns the input text".into()),
            input_schema: Some(serde_json::json!({
                "type": "object",
                "properties": {
                    "text": {"type": "string"}
                },
                "required": ["text"]
            })),
        },
        ToolManifest {
            name: "time_now".into(),
            description: Some("Returns current timestamp".into()),
            input_schema: Some(serde_json::json!({
                "type": "object",
                "properties": {}
            })),
        },
    ]
}
