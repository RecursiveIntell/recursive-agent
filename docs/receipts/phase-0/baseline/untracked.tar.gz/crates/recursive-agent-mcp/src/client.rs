//! MCP stdio client — connects to an external MCP server process
//! over stdin/stdout and calls its tools.

use std::io::{BufRead, BufReader, Write};
use std::process::{Child, Command, Stdio};

use crate::protocol::{InitializeResult, JsonRpcRequest, JsonRpcResponse, McpError, ToolManifest};

/// A connected MCP client that communicates with a child process
/// over stdio (newline-delimited JSON-RPC).
#[derive(Debug)]
pub struct McpClient {
    child: Child,
    request_id: u64,
}

impl McpClient {
    /// Connect to an MCP server by spawning the given command.
    /// Sends `initialize` and reads the server capabilities.
    pub fn connect(command: &str, args: &[String]) -> Result<Self, McpError> {
        let child = Command::new(command)
            .args(args)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::inherit())
            .spawn()
            .map_err(|e| McpError::Child(format!("spawn {command}: {e}")))?;

        let mut client = Self {
            child,
            request_id: 0,
        };

        // Send initialize.
        let params = serde_json::json!({
            "protocol_version": "2024-11-05",
            "capabilities": {},
            "client_info": {"name": "recursive-agent", "version": "0.1.0"}
        });
        let init_response: JsonRpcResponse = client.send_request("initialize", Some(params))?;

        if let Some(err) = init_response.error {
            return Err(McpError::Protocol(format!(
                "initialize rejected: {} (code {})",
                err.message, err.code
            )));
        }
        // Parse initialize result to confirm protocol version.
        let _init: InitializeResult = serde_json::from_value(
            init_response
                .result
                .ok_or_else(|| McpError::Protocol("initialize: no result".into()))?,
        )?;
        Ok(client)
    }

    /// Call `tools/list` and return available tools.
    pub fn list_tools(&mut self) -> Result<Vec<ToolManifest>, McpError> {
        let response: JsonRpcResponse = self.send_request("tools/list", None)?;
        if let Some(err) = response.error {
            return Err(McpError::Protocol(format!(
                "tools/list: {} (code {})",
                err.message, err.code
            )));
        }
        let result = response
            .result
            .ok_or_else(|| McpError::Protocol("tools/list: no result".into()))?;
        let tools: Vec<ToolManifest> = serde_json::from_value(
            result
                .get("tools")
                .cloned()
                .unwrap_or(serde_json::json!([])),
        )?;
        Ok(tools)
    }

    /// Call a specific tool with arguments.
    /// Returns the parsed result value, extracting from MCP content wrapper.
    pub fn call_tool(
        &mut self,
        name: &str,
        args: &serde_json::Value,
    ) -> Result<serde_json::Value, McpError> {
        let params = serde_json::json!({"name": name, "arguments": args});
        let response: JsonRpcResponse = self.send_request("tools/call", Some(params))?;
        if let Some(err) = response.error {
            return Err(McpError::Protocol(format!(
                "tools/call {}: {} (code {})",
                name, err.message, err.code
            )));
        }
        let result = response
            .result
            .ok_or_else(|| McpError::Protocol(format!("tools/call {name}: no result")))?;
        // Extract from MCP content wrapper: {"content": [{"type":"text","text":"<json>"}]}
        let content = result
            .get("content")
            .and_then(|c| c.as_array())
            .and_then(|arr| arr.first())
            .ok_or_else(|| McpError::Protocol("tools/call: no content".into()))?;
        let text = content["text"]
            .as_str()
            .ok_or_else(|| McpError::Protocol("tools/call: content has no text".into()))?;
        // Parse the text back as JSON (the server serializes the tool result as JSON text)
        serde_json::from_str(text).map_err(McpError::Json)
    }

    /// Send a JSON-RPC request and read the response.
    fn send_request(
        &mut self,
        method: &str,
        params: Option<serde_json::Value>,
    ) -> Result<JsonRpcResponse, McpError> {
        let id = self.next_id();
        let req = JsonRpcRequest {
            jsonrpc: "2.0".into(),
            id,
            method: method.into(),
            params,
        };
        let line = serde_json::to_string(&req)?;
        {
            let stdin = self
                .child
                .stdin
                .as_mut()
                .ok_or_else(|| McpError::Io("stdin not captured".into()))?;
            writeln!(stdin, "{line}").map_err(|e| McpError::Io(e.to_string()))?;
            stdin.flush().map_err(|e| McpError::Io(e.to_string()))?;
        }
        read_response(self.child.stdout.as_mut())
    }

    /// Try to terminate the child process.
    pub fn shutdown(&mut self) -> Result<(), McpError> {
        self.child
            .kill()
            .map_err(|e| McpError::Child(format!("kill: {e}")))?;
        self.child
            .wait()
            .map_err(|e| McpError::Child(format!("wait: {e}")))?;
        Ok(())
    }

    fn next_id(&mut self) -> u64 {
        self.request_id += 1;
        self.request_id
    }
}

/// Read a single JSON-RPC response line from stdout.
fn read_response(
    stdout: Option<&mut std::process::ChildStdout>,
) -> Result<JsonRpcResponse, McpError> {
    let out = stdout.ok_or_else(|| McpError::Io("stdout not captured".into()))?;
    let mut reader = BufReader::new(out);
    let mut line = String::new();
    reader
        .read_line(&mut line)
        .map_err(|e| McpError::Io(e.to_string()))?;
    if line.trim().is_empty() {
        return Err(McpError::Protocol("empty response from server".into()));
    }
    let response: JsonRpcResponse = serde_json::from_str(line.trim())?;
    Ok(response)
}

impl Drop for McpClient {
    fn drop(&mut self) {
        let _ = self.shutdown();
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;

    #[test]
    fn connect_to_nonexistent_command_fails() {
        let result = McpClient::connect("/nonexistent/command", &[]);
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert!(
            matches!(err, McpError::Child(_)),
            "expected Child error, got {err:?}"
        );
    }

    /// Test that an echo server works end-to-end.
    /// We spawn `ra mcp-serve` (our own binary) as the MCP server.
    #[test]
    fn connect_to_ra_mcp_serve_lists_tools() {
        // Locate the ra binary. In test mode cargo sets CARGO_BIN_EXE_ra
        // when the integration test has the right harness.
        // For unit tests we can use env!("CARGO_BIN_EXE_ra") only in
        // integration tests; here we fall back to the target path.
        let ra =
            std::env::var("CARGO_BIN_EXE_ra").unwrap_or_else(|_| "../../target/debug/ra".into());
        let mut client =
            McpClient::connect(&ra, &["mcp-serve".into()]).expect("connect to ra mcp-serve");
        let tools = client.list_tools().expect("list_tools should succeed");
        assert!(!tools.is_empty(), "ra should expose at least echo tool");
        // Verify echo is present.
        let echo = tools.iter().find(|t| t.name == "echo");
        assert!(echo.is_some(), "echo tool should be in manifest");

        // Call echo.
        let result = client
            .call_tool("echo", &serde_json::json!({"text": "hello-mcp"}))
            .expect("call echo");
        assert_eq!(result["text"], "hello-mcp");
    }

    #[test]
    fn malformed_server_output_is_rejected() {
        // This test validates that we handle garbage gracefully.
        // The connect fn validates initialize response, so bad init is caught.
        let result = McpClient::connect("/usr/bin/cat", &[]);
        assert!(result.is_err());
    }
}
