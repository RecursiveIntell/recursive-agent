//! recursive-agent MCP — client and server for Model Context Protocol.
//!
//! - `client`: connect to external MCP servers over stdio
//! - `server`: expose recursive-agent's own tools as an MCP server
//! - `protocol`: typed JSON-RPC 2.0 messages

pub mod client;
pub mod protocol;
pub mod server;
