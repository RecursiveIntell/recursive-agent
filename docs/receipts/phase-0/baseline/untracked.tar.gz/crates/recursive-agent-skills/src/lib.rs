//! Skill registry — file-based skill manifest loading and template expansion.
//! Skills are JSON files under a registry directory. Each skill defines
//! parameterized steps that can be expanded into a RunSpecV1.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum SkillError {
    #[error("io: {0}")]
    Io(#[from] std::io::Error),
    #[error("json: {0}")]
    Json(#[from] serde_json::Error),
    #[error("skill not found: {0}")]
    NotFound(String),
    #[error("missing required param: {0}")]
    MissingParam(String),
    #[error("unknown param: {0}")]
    UnknownParam(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SkillManifest {
    pub name: String,
    pub description: String,
    #[serde(default)]
    pub params: Vec<SkillParam>,
    pub steps: Vec<SkillStep>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SkillParam {
    pub name: String,
    #[serde(default = "default_param_type")]
    pub param_type: String,
    #[serde(default)]
    pub required: bool,
}

fn default_param_type() -> String {
    "string".into()
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SkillStep {
    pub name: String,
    pub tool: String,
    pub args: serde_json::Value,
}

pub struct SkillRegistry {
    root: PathBuf,
}

impl SkillRegistry {
    pub fn new(root: &Path) -> Self {
        Self {
            root: root.to_path_buf(),
        }
    }

    pub fn load(&self, name: &str) -> Result<SkillManifest, SkillError> {
        let path = self.root.join(format!("{name}.json"));
        if !path.exists() {
            return Err(SkillError::NotFound(name.into()));
        }
        let content = std::fs::read_to_string(&path)?;
        let manifest: SkillManifest = serde_json::from_str(&content)?;
        Ok(manifest)
    }

    pub fn list(&self) -> Result<Vec<String>, SkillError> {
        let mut names = Vec::new();
        if !self.root.exists() {
            return Ok(names);
        }
        for entry in std::fs::read_dir(&self.root)? {
            let entry = entry?;
            let path = entry.path();
            if path.extension().is_some_and(|e| e == "json") {
                if let Some(stem) = path.file_stem() {
                    names.push(stem.to_string_lossy().to_string());
                }
            }
        }
        Ok(names)
    }

    /// Expand a skill call into a list of tool call specs by binding parameters.
    pub fn expand(
        &self,
        skill_name: &str,
        bindings: &HashMap<String, serde_json::Value>,
    ) -> Result<Vec<SkillStep>, SkillError> {
        let manifest = self.load(skill_name)?;

        // Validate params.
        for param in &manifest.params {
            if param.required && !bindings.contains_key(&param.name) {
                return Err(SkillError::MissingParam(param.name.clone()));
            }
        }
        for key in bindings.keys() {
            if !manifest.params.iter().any(|p| &p.name == key) {
                return Err(SkillError::UnknownParam(key.clone()));
            }
        }

        // Substitute {param} placeholders in args.
        let steps: Vec<SkillStep> = manifest
            .steps
            .iter()
            .map(|step| {
                let args_str = serde_json::to_string(&step.args).unwrap_or_default();
                let mut substituted = args_str;
                for (key, val) in bindings {
                    let placeholder = format!("{{{key}}}");
                    let val_str = match val {
                        serde_json::Value::String(s) => s.clone(),
                        other => other.to_string(),
                    };
                    substituted = substituted.replace(&placeholder, &val_str);
                }
                let args: serde_json::Value =
                    serde_json::from_str(&substituted).unwrap_or(serde_json::Value::Null);
                SkillStep {
                    name: step.name.clone(),
                    tool: step.tool.clone(),
                    args,
                }
            })
            .collect();

        Ok(steps)
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;

    #[test]
    fn load_skill_from_file() {
        let tmp = tempfile::tempdir().unwrap();
        let skill = serde_json::json!({
            "name": "greet",
            "description": "Greet someone",
            "params": [{"name": "name", "required": true}],
            "steps": [
                {"name": "say_hi", "tool": "echo", "args": {"text": "Hello {name}!"}}
            ]
        });
        std::fs::write(
            tmp.path().join("greet.json"),
            serde_json::to_string_pretty(&skill).unwrap(),
        )
        .unwrap();

        let reg = SkillRegistry::new(tmp.path());
        let manifest = reg.load("greet").unwrap();
        assert_eq!(manifest.name, "greet");
        assert_eq!(manifest.steps.len(), 1);
    }

    #[test]
    fn expand_substitutes_params() {
        let tmp = tempfile::tempdir().unwrap();
        let skill = serde_json::json!({
            "name": "greet",
            "description": "Greet",
            "params": [{"name": "name", "required": true}],
            "steps": [
                {"name": "s1", "tool": "echo", "args": {"text": "Hello {name}!"}}
            ]
        });
        std::fs::write(
            tmp.path().join("greet.json"),
            serde_json::to_string_pretty(&skill).unwrap(),
        )
        .unwrap();

        let reg = SkillRegistry::new(tmp.path());
        let mut bindings = HashMap::new();
        bindings.insert("name".into(), serde_json::Value::String("World".into()));
        let steps = reg.expand("greet", &bindings).unwrap();
        assert_eq!(steps[0].args["text"], "Hello World!");
    }

    #[test]
    fn missing_required_param_fails() {
        let tmp = tempfile::tempdir().unwrap();
        let skill = serde_json::json!({
            "name": "greet",
            "description": "Greet",
            "params": [{"name": "name", "required": true}],
            "steps": []
        });
        std::fs::write(
            tmp.path().join("greet.json"),
            serde_json::to_string_pretty(&skill).unwrap(),
        )
        .unwrap();

        let reg = SkillRegistry::new(tmp.path());
        let bindings = HashMap::new();
        let err = reg.expand("greet", &bindings).unwrap_err();
        assert!(matches!(err, SkillError::MissingParam(_)));
    }
}
