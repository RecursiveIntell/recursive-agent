//! Persistent memory store — SQLite-backed key-value with BM25 search.
//! Used by the `memory_put`, `memory_get`, and `memory_search` tools.

use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use std::path::Path;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum MemoryError {
    #[error("sqlite: {0}")]
    Sqlite(#[from] rusqlite::Error),
    #[error("json: {0}")]
    Json(#[from] serde_json::Error),
    #[error("io: {0}")]
    Io(#[from] std::io::Error),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MemoryEntry {
    pub id: String,
    pub namespace: String,
    pub key: String,
    pub content: String,
    pub recorded_at: String,
}

pub struct MemoryStore {
    db: Connection,
}

impl MemoryStore {
    pub fn open(path: &Path) -> Result<Self, MemoryError> {
        let db = Connection::open(path)?;
        db.execute_batch(
            "CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY,
                namespace TEXT NOT NULL,
                key TEXT NOT NULL,
                content TEXT NOT NULL,
                recorded_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_memories_ns ON memories(namespace);
            CREATE INDEX IF NOT EXISTS idx_memories_key ON memories(namespace, key);",
        )?;
        Ok(Self { db })
    }

    pub fn put(&self, namespace: &str, key: &str, content: &str) -> Result<String, MemoryError> {
        let id = format!(
            "mem:{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_nanos()
        );
        self.db.execute(
            "INSERT INTO memories (id, namespace, key, content) VALUES (?1, ?2, ?3, ?4)",
            params![id, namespace, key, content],
        )?;
        Ok(id)
    }

    pub fn get(&self, namespace: &str, key: &str) -> Result<Option<MemoryEntry>, MemoryError> {
        let mut stmt = self.db.prepare(
            "SELECT id, namespace, key, content, recorded_at FROM memories WHERE namespace = ?1 AND key = ?2 ORDER BY recorded_at DESC LIMIT 1",
        )?;
        let entry = stmt
            .query_row(params![namespace, key], |row| {
                Ok(MemoryEntry {
                    id: row.get(0)?,
                    namespace: row.get(1)?,
                    key: row.get(2)?,
                    content: row.get(3)?,
                    recorded_at: row.get(4)?,
                })
            })
            .optional()?;
        Ok(entry)
    }

    pub fn search(
        &self,
        namespace: &str,
        query: &str,
        top_k: usize,
    ) -> Result<Vec<MemoryEntry>, MemoryError> {
        // BM25-inspired: tokenize query, score by term frequency in content.
        let tokens: Vec<String> = query.split_whitespace().map(|t| t.to_lowercase()).collect();

        let mut stmt = self.db.prepare(
            "SELECT id, namespace, key, content, recorded_at FROM memories WHERE namespace = ?1",
        )?;
        let rows: Vec<MemoryEntry> = stmt
            .query_map(params![namespace], |row| {
                Ok(MemoryEntry {
                    id: row.get(0)?,
                    namespace: row.get(1)?,
                    key: row.get(2)?,
                    content: row.get(3)?,
                    recorded_at: row.get(4)?,
                })
            })?
            .filter_map(|r| r.ok())
            .collect();

        // Score each entry.
        let mut scored: Vec<(f64, MemoryEntry)> = rows
            .into_iter()
            .map(|entry| {
                let content_lower = entry.content.to_lowercase();
                let score: f64 = tokens
                    .iter()
                    .map(|t| content_lower.matches(t).count() as f64)
                    .sum();
                (score, entry)
            })
            .filter(|(s, _)| *s > 0.0)
            .collect();

        scored.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
        scored.truncate(top_k);

        Ok(scored.into_iter().map(|(_, e)| e).collect())
    }
}

/// Polyfill for rusqlite OptionalExt
trait OptionalExt<T> {
    fn optional(self) -> Result<Option<T>, rusqlite::Error>;
}
impl<T> OptionalExt<T> for Result<T, rusqlite::Error> {
    fn optional(self) -> Result<Option<T>, rusqlite::Error> {
        match self {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e),
        }
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;

    #[test]
    fn put_and_get() {
        let tmp = tempfile::tempdir().unwrap();
        let store = MemoryStore::open(&tmp.path().join("test.db")).unwrap();
        let id = store.put("test", "greeting", "hello world").unwrap();
        assert!(id.starts_with("mem:"));
        let entry = store.get("test", "greeting").unwrap().unwrap();
        assert_eq!(entry.content, "hello world");
    }

    #[test]
    fn get_missing_returns_none() {
        let tmp = tempfile::tempdir().unwrap();
        let store = MemoryStore::open(&tmp.path().join("test.db")).unwrap();
        let entry = store.get("test", "nope").unwrap();
        assert!(entry.is_none());
    }

    #[test]
    fn search_finds_relevant() {
        let tmp = tempfile::tempdir().unwrap();
        let store = MemoryStore::open(&tmp.path().join("test.db")).unwrap();
        store
            .put("ns", "k1", "Rust is a systems programming language")
            .unwrap();
        store
            .put("ns", "k2", "Python is great for data science")
            .unwrap();
        store
            .put("ns", "k3", "Rust has great memory safety")
            .unwrap();
        let results = store.search("ns", "rust", 5).unwrap();
        assert_eq!(results.len(), 2);
    }
}
